/*
 * zlozonosc_alg1.cpp
 * 
 * Copyright 2018  <>
 * 
 */


#include <iostream>
using namespace std; 

int main(int argc, char **argv)
{
	int a = 0;
    cout << "Podaj a: "<< endl;
    cin >> a;
    
     for (int i=1;i < a;i += 2){
       
        if (a > 0 && a <100 ){
            cout<< a << endl;
        }
            
    
    

    
    
	return 0;
}

