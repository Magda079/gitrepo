/*
 * teksty.cpp
 */


#include <iostream>

using namespace std;
int main(int argc, char **argv)
{
	int i =0;
    for (i = 65; i<123; i++){
        cour << i << char(i)<< endl;
        }
    for (i = 97 )
	return 0;
}

