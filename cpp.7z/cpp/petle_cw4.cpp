/*
 * petle_cw4.cpp
 * 
 */


#include<iostream>
#include<conio.h>

using namespace std;

int main()
{
    int i;
    for(i=10;i<100;i++)
        {
        if(i%6==0)
            {
            cout<<i<<endl;
            }
        }
return 0;


}
